import pygame
class SpecialMove(pygame.sprite.Sprite):
	def __init__(self, xrect, yrect, attack_mode, fighters, attacks, screen, xrect_change, yrect_change, left):
		super().__init__()
		self.xrect_change, self.yrect_change = xrect_change, yrect_change
		self.screen = screen
		self.left = left
		self.attack_mode = attack_mode	
		if attack_mode == "spikeball":
			self.image = pygame.image.load('Spikeball.png').convert_alpha()
		elif attack_mode == 'ketchup':
			self.image = pygame.image.load('Ketchup.png').convert_alpha()

		elif attack_mode == 'communism':
			self.image = pygame.image.load('Sickle.png').convert_alpha()
		elif attack_mode == 'glitch':
			self.image = pygame.image.load('Glitch.png').convert_alpha()

		self.rect = self.image.get_rect()
		self.rect.x = xrect
		self.rect.y = yrect
		self.xer = float(self.rect.x)
		self.yer = float(self.rect.y)
		self.mask = pygame.mask.from_surface(self.image)
	def attack(self):
			if self.left:
				self.xer -= self.xrect_change
			else:
				self.xer += self.xrect_change
			self.yer += self.yrect_change
			self.rect.x = self.xer
			self.rect.y = self.yer
			self.screen.blit(self.image, self.rect)
