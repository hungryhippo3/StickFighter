import pygame
from pygame.font import Font
import time
class Round():
	def __init__(self, screen, loss, loss2):
		self.roundno = loss + loss2 + 1
		text = "Round " + str(self.roundno)
		font = Font(None, 28)
		text = font.render(text, True, (255, 255, 255))
		wext = str(loss) + ' - ' + str(loss2)
		wext = font.render(wext, True, (255, 255, 255))
		screen.blit(text, (500, 20))	
		screen.blit(wext, (520, 60))
		if loss == 3 or loss2 == 3:

			self.screen = screen
			self.loss = loss
			self.loss2 = loss2
			self.draws()
			
		else:
			pass		
	def draws(self):
		self.screen.fill((0, 255, 255))
		if self.loss2 > self.loss:
			nex = "Player 1 wins!"
		else:
			nex = "Player 2 wins!"
		font = Font(None, 48)
		nex = font.render(nex, True, (174, 178, 71))
		self.screen.blit(nex, (430, 40))
		self.game_over = True
