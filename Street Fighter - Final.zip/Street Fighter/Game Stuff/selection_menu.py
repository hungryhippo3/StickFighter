import pygame
from Settings import GameSettings
from button import Button
import game_functions as gf
class SelectionMenu():
	def __init__(self, screen, capable = True):
		self.screen = screen
		self.capable = capable
		self.adithya = pygame.image.load('AdithyaProfile.png').convert()
		self.krishna = pygame.image.load('KrishnaProfile.png').convert()
		self.soren = pygame.image.load('SorenProfile.png').convert()
		self.gabe = pygame.image.load('GabeProfile.png').convert()
		self.player = 1
		self.recta = self.adithya.get_rect()
		self.rectb = self.krishna.get_rect()
		self.rectc = self.soren.get_rect()
		self.rectd = self.gabe.get_rect()
		self.recta.x, self.recta.y = 495, 300
		self.rectb.x, self.rectb.y = 549, 300
		self.rectc.x, self.rectc.y = 603, 300
		self.rectd.x, self.rectd.y = 441, 300
		self.font = pygame.font.SysFont(None, 38)
		self.fontoo = pygame.font.SysFont(None, 16)		
		self.prepmsg()
		self.chosen = False
		
		self.x = 495
		self.tinyrect = [self.x, 400, 54, 4]
		self.underline()
		self.char_data()
		self.image_blit(screen)
	def prepmsg(self):
		self.msg = "Player "+str(self.player)+", choose your fighter. Use arrow keys to choose and the enter key for selection"
		if self.player == 2:
			self.msg2 = "You cannot pick the same fighter as player 1."
		else:
			self.msg2 = ''
		self.msg_image = self.font.render(self.msg, True, (0, 0, 0),
			(255, 255, 210))
		self.msg2_image = self.font.render(self.msg2, True, (0, 0, 0),
			(255, 255, 210))
		self.msg_image_rect = self.msg_image.get_rect()
	def char_data(self):
		self.namea = "Adithya"
		self.namek = "Krishna"
		self.names = "Soren"
		self.nameg = "Gabe"
		self.dataa = ["HP: 2/5", "Attack: 4/5", "Speed: 4/5", "Jump: 3/5"]
		self.datak = ["HP: 4.5/5", "Attack: 3/5", "Speed: 2/5", "Jump: 2/5"]
		self.datas = ["HP: 3.5/5", "Attack: 3.5/5", "Speed: 2.5/5", "Jump: 2.5/5"]
		self.datag = ["HP: 1.5/5", "Attack: 2.5/5", "Speed: 3.5/5", "Jump: 3.5/5"]
		self.namea_image = self.fontoo.render(self.namea, True, (0, 0, 0), (255, 255, 210))
		self.namek_image = self.fontoo.render(self.namek, True, (0, 0, 0), (255, 255, 210))
		self.names_image = self.fontoo.render(self.names, True, (0, 0, 0), (255, 255, 210))
		self.nameg_image = self.fontoo.render(self.nameg, True, (0, 0, 0), (255, 255, 210))
		self.q = 352
	def utilize(self):
		if self.capable:
			for event in pygame.event.get():
				if event.type == pygame.KEYDOWN:
					if event.key == pygame.K_RIGHT and self.x < 603:
						self.x += 54
						self.image_blit(self.screen)
					if event.key == pygame.K_LEFT and self.x > 451:
						self.x -= 54
						self.image_blit(self.screen)
					self.tinyrect =[self.x, 400, 54, 4]
					self.underline()
					#pygame.display.flip()
					if event.key == pygame.K_RETURN:
						if self.x == 441:
							return('Gabe')
						if self.x == 495:
							return('Adithya')
						
						elif self.x == 549:
							return('Krishna')
							
						elif self.x == 603:
							return('Soren')
					return()
			
	
	def underline(self):
		#self.screen.fill((255, 0, 0), self.tinyrect)
		pygame.draw.rect(self.screen, (255, 0, 0), self.tinyrect)		
	def image_blit(self, screen):
		screen.fill((255, 255, 210))
		screen.blit(self.adithya, self.recta)
		screen.blit(self.krishna, self.rectb)
		screen.blit(self.soren, self.rectc)
		screen.blit(self.gabe, self.rectd)
		screen.blit(self.msg_image, self.msg_image_rect)
		screen.blit(self.msg2_image, (0, 50))
		screen.blit(self.namea_image, (495, 284))
		screen.blit(self.namek_image, (549, 284))
		screen.blit(self.names_image, (603, 284))
		screen.blit(self.nameg_image, (441, 284))
		if self.x == 495:
			for data in self.dataa:
				image = self.fontoo.render(data, True, (0, 0, 0), (255, 255, 210))
				self.screen.blit(image, (495, self.q))
				self.q+= 10
			self.q = 352
		elif self.x == 549:
			for data in self.datak:
				image = self.fontoo.render(data, True, (0, 0, 0), (255, 255, 210))
				self.screen.blit(image, (549, self.q))
				self.q += 10
			self.q = 352
		elif self.x == 603:
			for data in self.datas:
				image = self.fontoo.render(data, True, (0, 0, 0), (255, 255, 210))
				self.screen.blit(image, (603, self.q))
				self.q += 10
			self.q = 352
		elif self.x == 441:
			for data in self.datag:
				image = self.fontoo.render(data, True, (0, 0, 0), (255, 255, 210))
				self.screen.blit(image, (441, self.q))
				self.q += 10
			self.q = 352
	
