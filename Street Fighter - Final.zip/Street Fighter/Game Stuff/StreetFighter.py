import sys
import time
from Settings import GameSettings
import pygame
from fighter import Fighter
import game_functions as gf
from health_bar import HealthBar
from button import Button
from selection_menu import SelectionMenu
def run_game():
	pygame.init()
	
	pygame.mixer.init()
	
	screen = pygame.display.set_mode((1098, 618))
	

	pygame.display.set_caption('Street Fighter')
	
	attacks = pygame.sprite.Group()
	fighters = pygame.sprite.Group()
	specials = pygame.sprite.Group()
	pygameload = pygame.image.load('PygameIntro.png').convert()
	logo = pygame.image.load('GameLogo.png').convert_alpha()
	production = pygame.image.load('Adithya.png').convert_alpha()
	select_sound = pygame.mixer.Sound('power.wav')
	settings = GameSettings(screen)
	active = True

	a = 0
	while active:
		if not settings.ng:
			screen.fill((0, 0, 0))
			screen.blit(pygameload, (149, 53))
			pygame.display.flip()
			time.sleep(1.5)
			screen.fill((0, 0, 0))
			screen.blit(production, (149, 53))
			pygame.display.flip()			
			time.sleep(1.5)
			screen.fill((255, 255, 210))
			
			screen.blit(logo, (288.5, 100))
			m = 'Play'
		elif settings.ng:
			m = 'Play Again'
		play_button = Button((100, 255, 55), 449, 300, 200, 30, screen, m)
		play_button.draw_button()
		play_button.text_color = (0, 0, 0)
		pygame.display.flip()
		menu = True
		while menu:
			gf.mouse_check_play_button(screen, play_button, settings)
			if settings.choose_active:
				menu = False 
		
		screen.fill((255, 255, 210))
		pygame.mixer.music.load(settings.menutheme)
		pygame.mixer.music.play(-1)
		item = SelectionMenu(screen)
		player_1choose = True
		playerk = 0
		playera = 0
		players = 0
		playerg = 0
		adithya_a = False
		krishna_a = False
		soren_a = False
		gabe_a = False
		while settings.choose_active:
			if player_1choose:
				x = item.utilize()
				pygame.display.flip()
				if x == 'Adithya':
					playera = 1
					select_sound.play()
					adithya_a = True
					player_1choose = False
					item.player += 1
					item.prepmsg()
					
				elif x == 'Krishna':
					playerk = 1
					select_sound.play()
					krishna_a = True
					player_1choose = False
					item.player += 1
					item.prepmsg()
					
				elif x == 'Soren':
					players = 1
					select_sound.play()
					soren_a = True
					player_1choose = False
					item.player += 1
					item.prepmsg()
					
				elif x == 'Gabe':
					playerg = 1
					select_sound.play()
					gabe_a = True
					player_1choose = False
					item.player += 1
					item.prepmsg()
									
			else:
				y = item.utilize()
				pygame.display.flip()
				if y == 'Adithya' and not x == "Adithya":
					playera = 2
					select_sound.play()
					adithya_a = True
					settings.choose_active = False
					
				elif y == 'Krishna' and not x == "Krishna":
					playerk = 2
					select_sound.play()
					krishna_a = True
					settings.choose_active = False
					
				elif y == 'Soren' and not x == 'Soren':
					players = 2
					select_sound.play()
					soren_a = True
					settings.choose_active = False
					
				elif y == 'Gabe' and not x == 'Gabe':
					playerg = 2
					select_sound.play()
					gabe_a = True
					settings.choose_active = False
					
		krishna = [screen, settings, 1.95, 20, 8, 360, playerk,
				'RightSpriteKrishna.png',
				'RightJumpingKrishna.png',
				'RightDuckingKrishna.png',
				'LeftDuckingKrishna.png', 
				'LeftJumpingKrishna.png', 
				'LeftSpriteKrishna.png', 
				'RightPunchKrishna.png', 
				'LeftPunchKrishna.png', 
				'RightKickKrishna.png', 
				'LeftKickKrishna.png',
				'LeftJumpKickKrishna.png',
				'RightJumpKickKrishna.png',
				'LeftDuckPunchKrishna.png',
				'RightDuckPunchKrishna.png',
				'RightSpecialKrishna.png',
				'LeftSpecialKrishna.png',
				'Ketchup.png',
				'KrishnaProfile.png']
		soren = [screen, settings, 2.25, 28, 9, 300, players,
				'RightSpriteSoren.png',
				'RightJumpingSoren.png',
				'RightDuckingSoren.png',
				'LeftDuckingSoren.png', 
				'LeftJumpingSoren.png', 
				'LeftSpriteSoren.png', 
				'RightPunchSoren.png', 
				'LeftPunchSoren.png', 
				'RightKickSoren.png', 
				'LeftKickSoren.png',
				'LeftJumpKickSoren.png',
				'RightJumpKickSoren.png',
				'LeftDuckPunchSoren.png',
				'RightDuckPunchSoren.png',
				'RightSpecialSoren.png',
				'LeftSpecialSoren.png',
				'Sickle.png',
				'SorenProfile.png']		
		adithya = [screen, settings, 3, 35, 10, 230, playera]
		gabe = [screen, settings, 2.55, 40, 7, 200, playerg,
				'RightSpriteGabe.png',
				'RightJumpingGabe.png',
				'RightDuckingGabe.png',
				'LeftDuckingGabe.png', 
				'LeftJumpingGabe.png', 
				'LeftSpriteGabe.png', 
				'RightPunchGabe.png', 
				'LeftPunchGabe.png', 
				'RightKickGabe.png', 
				'LeftKickGabe.png',
				'LeftJumpKickGabe.png',
				'RightJumpKickGabe.png',
				'LeftDuckPunchGabe.png',
				'RightDuckPunchGabe.png',
				'RightSpecialGabe.png',
				'LeftSpecialGabe.png',
				'Glitch.png',
				'GabeProfile.png']	
		if adithya_a:
			if playera == 1:
				fighter = Fighter(*adithya)
			elif playera == 2:
				fightertwo = Fighter(*adithya)
		if krishna_a:
			if playerk == 1:
				fighter = Fighter(*krishna)
			elif playerk == 2:
				fightertwo = Fighter(*krishna)		
		if soren_a:
			if players == 1:
				fighter = Fighter(*soren)
			elif players == 2:
				fightertwo = Fighter(*soren)
		if gabe_a:
			if playerg == 1:
				fighter = Fighter(*gabe)
			elif playerg == 2:
				fightertwo = Fighter(*gabe)
		fighters.add(fighter)
		fighters.add(fightertwo)
		pygame.mixer.music.stop()
		settings.game_active = True
		while settings.game_active:
			pygame.mixer.music.load(settings.music)
			pygame.mixer.music.play(-1)
			settings.game = True
			while settings.game:
				gf.screen_update(screen, settings, fighter, fightertwo, attacks, fighters)
				gf.checkify(settings, fighters, fighter, fightertwo)
run_game()
