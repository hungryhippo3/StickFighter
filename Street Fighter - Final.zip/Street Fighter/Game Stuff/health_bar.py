import pygame
from pygame.font import Font
class HealthBar():
	def __init__(self, screen, hp, hp_init, player, profile):
		self.player = player
		self.hp = hp
		self.screen = screen
		self.hp_init = hp_init
		self.profile = profile.convert()
		if self.player == 2:
			self.x, self.y = 0, 0
			self.px, self.py = 205, 0
		else:
			self.x, self.y = 898, 0
			self.px, self.py = 837, 0
		if self.hp > 0.5 * hp_init:
			self.color = (0, 255, 0)
		elif 0.25 * hp_init <= self.hp <= 0.5*hp_init:
			self.color =  (255, 255, 0)
		else:
			self.color = (255, 0, 0)
		if self.hp < 0:
			self.hp = 0
		self.drawrect()
	def drawrect(self):
		pygame.draw.rect(self.screen, self.color, [self.x, self.y, 0.5*self.hp, 30])
		text = ('HP: ' + str(self.hp) + '/' + str(self.hp_init))
		font = Font(None, 20)
		text = font.render(text, True, (255, 255, 255))
		self.screen.blit(text, (self.x, 32))
		self.screen.blit(self.profile, (self.px, self.py))
