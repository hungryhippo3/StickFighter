import pygame
from fighter import Fighter
class AI(pygame.sprite.Sprite):
	def __init__(self, fighter, fightertwo, settings):
		super().__init__()
		self.fighter = fighter
		self.fightertwo = fightertwo
		self.settings = settings
	def detect_location(self, fightertwo):
		self.detection = fightertwo.rect.x
		if fightertwo.rect.x >= self.fighter.rect.x:
			self.rightdetect = True
		else:
			self.rightdetect = False
	def detect_motion(self, fightertwo):
		self.detect_location(fightertwo)
		if fightertwo.moving_right:
			self.rightmoving = True
		elif fightertwo.moving_left:
			self.leftmoving = True
		else:
			self.rightmoving, self.leftmoving = False, False
		
