import pygame
class Puncher(pygame.sprite.Sprite):
	def __init__(self, xrect, yrect, attack, fighters, attacks):
		#pygame.sprite.Sprite().__init__()
		super().__init__()
		#def punch(self):
		self.image = pygame.image.load('Attack.png')#self.rect
		self.rect = self.image.get_rect()
		self.rect.x = xrect
		self.rect.y = yrect
		self.mask = pygame.mask.from_surface(self.image)
		#if collrect:
			#print('pow')
	def printer(self):
		print(self.xrect, self.yrect)
