import pygame
import sys
from puncher import Puncher
from health_bar import HealthBar
from power_bar import PowerBar
from special_moves import SpecialMove
from round import Round

def update_fighters(fighter, fightertwo, attacks, fighters, screen):
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
					sys.exit()
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_n and not fighter.jumping:
					if fighter.tracker < 3:
						fighter.punch = True
						attack(fightertwo, fighter, attacks, fighters)
					else:
						fighter.tracker = 0
				if event.key == pygame.K_m and not fighter.ducking:
					if fighter.tracker < 3:
						fighter.kick = True
						attack(fightertwo, fighter, attacks, fighters)
					else:
						fighter.tracker = 0
				if event.key == pygame.K_b and fighter.energy >= 200:
					fighter.ducking = False
					fighter.jumping = False
					fighter.special = True
					
				if event.key == pygame.K_z and fightertwo.energy >= 200:
					fightertwo.ducking = False
					fightertwo.jumping = False
					fightertwo.special = True
				if event.key == pygame.K_RIGHT:
					fighter.moving_right = True
					fighter.right = True
					fighter.left = False
					
				if event.key == pygame.K_LEFT:
					fighter.moving_left = True
					fighter.left = True
					fighter.right = False
				
				if event.key == pygame.K_DOWN and not fighter.jumping:
					fighter.ducking = True
				
				if event.key == pygame.K_UP and not fighter.ducking and not fighter.jumping:
					fighter.jumping = True
					
				if event.key == pygame.K_d:
					fightertwo.moving_right = True
					fightertwo.right = True
					fightertwo.left = False
						
				if event.key == pygame.K_a:
	
					fightertwo.moving_left = True
					fightertwo.left = True
					fightertwo.right = False
					
					
				if event.key == pygame.K_s and not fightertwo.jumping:
					fightertwo.ducking = True
					
				if event.key == pygame.K_w and not fightertwo.ducking and not fightertwo.jumping:
					fightertwo.jumping = True
				
				if event.key == pygame.K_x and not fightertwo.jumping:
					if fightertwo.tracker < 3:
						fightertwo.punch = True
						attack(fighter, fightertwo, attacks, fighters)
					else:
						fightertwo.tracker = 0
					
				if event.key == pygame.K_c and not fightertwo.ducking:
					if fightertwo.tracker < 3:
						fightertwo.kick = True
						attack(fighter, fightertwo, attacks, fighters)
					else:
						fightertwo.tracker = 0
			elif event.type == pygame.KEYUP:
				if event.key == pygame.K_RIGHT:
					fighter.moving_right = False
				elif event.key == pygame.K_LEFT:
					fighter.moving_left = False
				elif event.key == pygame.K_DOWN:
					fighter.ducking = False
				elif event.key == pygame.K_d:
					fightertwo.moving_right = False
				elif event.key == pygame.K_a:
					fightertwo.moving_left = False
				elif event.key == pygame.K_s:
					fightertwo.ducking = False
	
def mouse_check_play_button(screen, play_button, settings):
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
					sys.exit()
		if event.type == pygame.MOUSEBUTTONDOWN:
			mouse_x, mouse_y = pygame.mouse.get_pos()
			check_play_button(screen, play_button, mouse_x, mouse_y, settings)


def create_floor(screen, settings, fighter):
	pygame.draw.rect(screen, settings.floorcolor, [0, 548, settings.screen_width, settings.screen_height - 500])

def screen_update(screen, settings, fighter, fightertwo, attacks, fighters):
	pygame.display.flip()
	screen.blit(settings.background, (0, 0))
	create_floor(screen, settings, fighter)
	update_fighters(fighter, fightertwo, attacks, fighters, screen)
	image_update(fighter, fightertwo)
	
	special(fighter, fightertwo, screen, fighters, attacks, settings)
	health_bars(fighter, fightertwo, screen)
	
		

def image_update(fighter, fightertwo):
	fighter.update()
	fightertwo.update()
	fighter.update_image()
	fightertwo.update_image()
	fighter.blitme()
	fightertwo.blitme()

def attack(fighter, fightertwo, attacks, fighters):
	if fightertwo.special == False:
		x, y = fightertwo.returnxy()
		new_attack = Puncher(x, y, fightertwo.attack, fighters, attacks)

		attacks.add(new_attack)
		collrect = pygame.sprite.groupcollide(attacks, fighters, False, False)
		if collrect:
			maskrect = pygame.sprite.groupcollide(attacks, fighters, False, False, pygame.sprite.collide_mask)
			if maskrect:
				if fightertwo.punch:
					fighter.hp -= fightertwo.attack
					fightertwo.energy += 13
				elif fightertwo.kick:
					fighter.hp -= int(1.3*fightertwo.attack)
					fightertwo.energy += 16
			if fighter.hp <= 0:
				fighter.loss += 1
				reset(fighters, fighter, fightertwo, attacks)
		attacks.remove(new_attack)
	else:
		pass
def check_play_button(screen, play_button, mouse_x, mouse_y, settings):
	button_clicked = play_button.rect.collidepoint(mouse_x, mouse_y)
	if button_clicked and settings.game_active == False:
		if settings.choose_active == False:
			settings.choose_active = True
		if settings.choose_active == True:
			return('Clicked')
def health_bars(fighter, fightertwo, screen):
	f2bar = HealthBar(screen, fightertwo.hp, fightertwo.hp_init, fightertwo.player, fightertwo.P)
	f1bar = HealthBar(screen, fighter.hp, fighter.hp_init, fighter.player, fighter.P)
	f2power = PowerBar(fightertwo.energy, screen, fightertwo.player)
	
	f1power = PowerBar(fighter.energy, screen, fighter.player)
	roundno = Round(screen, fighter.loss, fightertwo.loss)

def spikeball(fighter, fightertwo, screen, fighters, attacks, settings):
	if fighter.condition == True:
		if fighter.adithyaspecial:
			x, y, z = fighter.returnxy()
			settings.spikeball = SpecialMove(x, y, z, fighters, attacks, screen, 4, 0, fighter.left)
			settings.spikeball2 = SpecialMove(x, y, z, fighters, attacks, screen, 3.5, 1, fighter.left)
			settings.spikeball3 = SpecialMove(x, y, z, fighters, attacks, screen, 3.5, -1, fighter.left)
			attacks.add(settings.spikeball), attacks.add(settings.spikeball2), attacks.add(settings.spikeball3)
			settings.blasttrue = True
			fighter.condition = False
	else:
		if settings.blasttrue == True:
			settings.blasttrue = False
		settings.spikeball.attack(), settings.spikeball2.attack(), settings.spikeball3.attack()
		special_collide(settings, fightertwo, fighter, fighters, attacks)
def special_collide(settings, fighter, fightertwo, fighters, attacks):
		collrect = pygame.sprite.groupcollide(attacks, fighters, False, False)
		if collrect:
			maskrect = pygame.sprite.groupcollide(attacks, fighters, True, False, pygame.sprite.collide_mask)
			if maskrect:			
				if fightertwo.adithyaspecial: 
					fighter.hp -= 20
					settings.poptrue = True
					settings.popa += 1
				if fightertwo.krishnaspecial: 
					fighter.hp -= 30
					settings.splattrue = True
					settings.splata += 1
				if fightertwo.sorenspecial: fighter.hp -= 70
				if fightertwo.gabespecial:
					fightertwo.hp += int(0.5 * fighter.hp)
					if fightertwo.hp > 200:
						fightertwo.hp = 200
					fighter.hp = int(0.5 * fighter.hp)
			if fighter.hp <= 0:
				fighter.loss += 1
				reset(fighters, fighter, fightertwo, attacks)
def ketchup(fighter, fightertwo, screen, fighters, attacks, settings):
	if fighter.condition == True:
		if fighter.krishnaspecial:
			x, y, z = fighter.returnxy()
			settings.ketchup = SpecialMove(x, y, z, fighters, attacks, screen, 3, 0.1, fighter.left)
			settings.ketchup2 = SpecialMove(x, y, z, fighters, attacks, screen, 3, 0.1, fighter.left)
			attacks.add(settings.ketchup)
			settings.blasttrue = True
			fighter.condition = False
	if fighter.specialcount == 60:
		attacks.add(settings.ketchup2)
		settings.blasttrue = True

	if fighter.condition == False:
		if fighter.specialcount <= 60:
			if settings.blasttrue and 1 < fighter.specialcount < 60:
				settings.blasttrue = False
			settings.ketchup.attack()
			fighter.moving_left, fighter.moving_right = False, False
		else:
			if settings.blasttrue:
				settings.blasttrue = False			
			settings.ketchup.attack(), settings.ketchup2.attack()
		special_collide(settings, fightertwo, fighter, fighters, attacks)
def communism(fighter, fightertwo, screen, fighters, attacks, settings):		
	if fighter.condition == True:
		if fighter.sorenspecial:
			x, y, z = fighter.returnxy()
			settings.communism = SpecialMove(x, y, z, fighters, attacks, screen, 5, 0, fighter.left)
			attacks.add(settings.communism)
			settings.swingtrue = True
			fighter.condition = False
	elif fighter.condition == False:
		if settings.swingtrue:
			settings.swingtrue = False
		settings.communism.attack()
		special_collide(settings, fightertwo, fighter, fighters, attacks)
def glitch(fighter, fightertwo, screen, fighters, attacks, settings):
	if fighter.condition == True:
		if fightertwo.right:
			x, y = fightertwo.rect.centerx, fightertwo.rect.top
		else:
			x, y = fightertwo.rect.x, fightertwo.rect.top
		settings.glitch = SpecialMove(x, y, 'glitch', fighters, attacks, screen, 0, 0, fighter.left)
		attacks.add(settings.glitch)
		settings.bleeptrue = True
		fighter.condition = False
	elif fighter.condition == False:
		if settings.bleeptrue:
			settings.bleeptrue = False
		settings.glitch.attack()
		special_collide(settings, fightertwo, fighter, fighters, attacks)
def special(fighter, fightertwo, screen, fighters, attacks, settings):
	if fighter.hp > 0 and fightertwo.hp > 0:
		if fighter.adithyaspecial or fightertwo.adithyaspecial:
			if fighter.special and fighter.adithyaspecial:
				
				spikeball(fighter, fightertwo, screen, fighters, attacks, settings)
			elif fightertwo.special and fightertwo.adithyaspecial:
				spikeball(fightertwo, fighter, screen, fighters, attacks, settings)
			else:
				if settings.spikeball != None:
					attacks.remove(settings.spikeball), attacks.remove(settings.spikeball2), attacks.remove(settings.spikeball3)					
					settings.spikeball, settings.spikeball2, settings.spikeball3 = None, None, None

		if fighter.krishnaspecial or fightertwo.krishnaspecial:
			if fighter.special and fighter.krishnaspecial:
				ketchup(fighter, fightertwo, screen, fighters, attacks, settings)
			elif fightertwo.special and fightertwo.krishnaspecial:
				ketchup(fightertwo, fighter, screen, fighters, attacks, settings)
			else:
				if settings.ketchup != None:
					attacks.remove(settings.ketchup), attacks.remove(settings.ketchup2)					
					settings.ketchup, settings.ketchup2 = None, None

		if fighter.sorenspecial or fightertwo.sorenspecial:
			if fighter.special and fighter.sorenspecial:
				communism(fighter, fightertwo, screen, fighters, attacks, settings)
			elif fightertwo.special and fightertwo.sorenspecial:
				communism(fightertwo, fighter, screen, fighters, attacks, settings)
			else:
				if settings.communism != None:
					attacks.remove(settings.communism)
					settings.communism = None

		if fighter.gabespecial or fightertwo.gabespecial:
			if fighter.special and fighter.gabespecial:
				glitch(fighter, fightertwo, screen, fighters, attacks, settings)
			elif fightertwo.special and fightertwo.gabespecial:
				glitch(fightertwo, fighter, screen, fighters, attacks, settings)
			else:
				if settings.glitch != None:
					attacks.remove(settings.glitch)
					settings.glitch = None

def reset(fighters, fighter, fightertwo, attacks):
	if fighter.loss >= 3 or fightertwo.loss >= 3:
		fighter.game_over = True
	else:
		fighter.game_over = False
	if fighter.hp <= 0 or fightertwo.hp <= 0 and not game_over:
		fighters.empty()
		attacks.empty()
		fighters.add(fighter), fighters.add(fightertwo)
		fighter.reset(), fightertwo.reset()
def checkify(settings, fighters, fighter, fightertwo):
				if settings.blasttrue:
					pygame.mixer.Sound.play(settings.blast)
				if settings.swingtrue:
					pygame.mixer.Sound.play(settings.swing)
				if settings.bleeptrue:
					pygame.mixer.Sound.play(settings.bleep)
				if settings.poptrue and settings.popa == 1:
					pygame.mixer.Sound.play(settings.pop)
					settings.poptrue = False
					settings.popa = 0
				if settings.splattrue and settings.splata == 1:
					pygame.mixer.Sound.play(settings.splat)
					settings.splattrue = False
					settings.splata = 0
				if fighter.game_over or fightertwo.game_over:
					settings.game = False
					settings.game_active = False
					pygame.mixer.music.stop()
					fighters.remove(fighter)
					fighters.remove(fightertwo)
					settings.bleeptrue, settings.swingtrue, settings.blasttrue, settings.poptrue, settings.splattrue = False, False, False, False, False
					settings.ng = True
					settings.regen()
