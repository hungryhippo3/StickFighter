import pygame
from pygame.font import Font
class PowerBar():
	def __init__(self, energy, screen, player):
		self.energy = energy
		self.player = player
		self.screen = screen
		self.font = Font(None, 20)
		
		if self.player == 2:
			self.x, self.y = 0, 60
		elif self.player == 1:
			self.x, self.y = 898, 60
		self.green = 55 + self.energy
		self.color = (255, 55+self.energy, 255)
		self.drawrect()
	def drawrect(self):
		pygame.draw.rect(self.screen, self.color, [self.x, self.y, self.energy, 15])
		if self.energy == 200:
			text = self.font.render("Ready!", True, (0, 0, 0))
			self.screen.blit(text, (self.x + 10, 60))
