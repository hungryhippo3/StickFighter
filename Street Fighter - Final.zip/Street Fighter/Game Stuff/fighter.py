import pygame
import time
from puncher import Puncher
#This is the class for a fighter
class Fighter(pygame.sprite.Sprite):
	def __init__(self, screen, settings, speed, jump, attack,
	HP, player, 
	rightsprite = 'RightSpriteAdithya.png',
	rightjumping = 'RightJumpingAdithya.png',
	rightducking = 'RightDuckingAdithya.png',
	leftducking = 'LeftDuckingAdithya.png', 
	leftjumping = 'LeftJumpingAdithya.png', 
	leftsprite = 'LeftSpriteAdithya.png', 
	rightpunch = 'RightPunchAdithya.png', 
	leftpunch = 'LeftPunchAdithya.png', 
	rightkick = 'RightKickAdithya.png', 
	leftkick = 'LeftKickAdithya.png',
	leftjumpkick = 'LeftJumpKickAdithya.png',
	rightjumpkick = 'RightJumpKickAdithya.png',
	leftduckpunch = 'LeftDuckPunchAdithya.png',
	rightduckpunch = 'RightDuckPunchAdithya.png',
	rightspecial = 'RightSpecialAdithya.png',
	leftspecial = 'LeftSpecialAdithya.png',
	speciallaunch = 'Spikeball.png',
	profile = 'AdithyaProfile.png'):
		super().__init__()
		self.screen = screen
		self.screen_rect = screen.get_rect()
		self.player = player
		if self.player == 2:
			self.left = False
			self.right = True
		if self.player == 1:
			self.right = False
			self.left = True
		self.ducking = False
		self.jumping = False
		self.adithyaspecial = False
		self.krishnaspecial = False
		self.sorenspecial = False
		self.gabespecial = False
		if speciallaunch == 'Spikeball.png':
			self.adithyaspecial = True
		elif speciallaunch == 'Ketchup.png':
			self.krishnaspecial = True
		elif speciallaunch == 'Sickle.png':
			self.sorenspecial = True
		elif speciallaunch == 'Glitch.png':
			self.gabespecial = True
		self.punch = False
		self.kick = False
		self.special = False
		self.moving_right = False
		self.moving_left = False
		self.gravity = False
		self.block = False
		self.hp = HP
		self.hp_init = HP
		self.speed_init = speed
		self.energy = 0
		self.specialcount = 0
		self.speed = speed
		self.cooldown = 0
		self.jump_count = jump
		self.jump_init = jump
		self.attack = attack
		self.condition = True
		self.game_over = False
		self.loss = 0
		self.StA = pygame.image.load(rightsprite).convert_alpha()#Try making pngs, use alpha convert instead to mask
		self.JuA = pygame.image.load(rightjumping).convert_alpha()
		self.DuA = pygame.image.load(rightducking).convert_alpha()
		self.DuAL = pygame.image.load(leftducking).convert_alpha()
		self.JuAL = pygame.image.load(leftjumping).convert_alpha()
		self.StAL = pygame.image.load(leftsprite).convert_alpha()
		self.StAP = pygame.image.load(rightpunch).convert_alpha()
		self.StALP = pygame.image.load(leftpunch).convert_alpha()
		self.StALK = pygame.image.load(leftkick).convert_alpha()
		self.StAK = pygame.image.load(rightkick).convert_alpha()
		self.JuAK = pygame.image.load(rightjumpkick).convert_alpha()
		self.JuALK = pygame.image.load(leftjumpkick).convert_alpha()
		self.DuAP = pygame.image.load(rightduckpunch).convert_alpha()
		self.DuALP = pygame.image.load(leftduckpunch).convert_alpha()
		self.SpA = pygame.image.load(rightspecial).convert_alpha()
		self.SpAL = pygame.image.load(leftspecial).convert_alpha()
		self.Sp = pygame.image.load(speciallaunch).convert_alpha()
		self.P = pygame.image.load(profile)
		if self.player == 2:
			self.init_image = self.StA
		else:
			self.init_image = self.StAL
		self.rect = self.init_image.get_rect()
		self.attack_count = 0
		self.tracker = 0
		if self.player == 2:
			self.rect.centerx = 50
		if self.player == 1:
			self.rect.centerx = 1046
		self.rect.bottom = 548
		self.image = self.init_image
		self.center = float(self.rect.centerx)
		self.vcenter = float(self.rect.centery)
		self.gravax = 0.5
		self.attackbox = False
	def blitme(self):
		if self.hp > 0:
			self.screen.blit(self.image, self.rect)
		else:
			pass
	def update(self):
		if self.special:
			self.punch, self.kick = False, False
		if self.moving_right and self.rect.right < 1098:
			self.center += self.speed
		elif self.moving_left and self.rect.left > 0:
			self.center -= self.speed
		if self.jumping and not self.special:
			if self.jump_count >= -self.jump_init:
				neg = 1
				if self.jump_count < 0:
					neg = -1
				self.vcenter -= (self.jump_count ** 2) * 0.5 * neg
				self.jump_count -= 1
			else:
				self.jump_count = self.jump_init
				self.jumping = False
		if self.energy > 200:
			self.energy = 200
		if self.special:
			self.energy = 0
		self.rect.centerx = self.center
		self.rect.centery = self.vcenter
		self.mask = pygame.mask.from_surface(self.image)
	def returnxy(self):
		if self.hp > 0 and self.special == False and self.cooldown == 0:
			if self.punch:
				y = self.rect.top + 40
			elif self.kick:
				if not self.jumping:
					y = self.rect.top + 124
				else:
					y = self.rect.top + 112
			
			if not self.jumping:
				if self.right:
					x = self.rect.right + 1
				if self.left:
					x = self.rect.left - 11
			else:
				if self.right:
					x = self.rect.left + 33
				if self.left:
					x = self.rect.right - 33 
			return(x, y)
		elif self.special and self.hp > 0:		
			if self.adithyaspecial:
				if self.right:
					x = self.rect.right + 1
					y = self.rect.top + 33
				elif self.left:
					x = self.rect.left - 35
					y = self.rect.top + 33
			if self.krishnaspecial:	
				if self.right:
					x = self.rect.right + 1
					y = self.rect.top + 33
				elif self.left:
					x = self.rect.left - 96
					y = self.rect.top + 33
			if self.sorenspecial:
				if self.right:
					x = self.rect.right + 1
					y = self.rect.top + 50
				elif self.left:
					x = self.rect.left - 38
					y = self.rect.top + 50
				
					
			if self.adithyaspecial: return(x, y, "spikeball")
			elif self.krishnaspecial: return(x, y, 'ketchup')
			elif self.sorenspecial: return(x, y, 'communism')
		else:
			return(0, 0)
			
	def update_image(self):
		
			if self.cooldown != 0:
				self.cooldown -= 1
			if not self.ducking and not self.jumping and not self.special:
				if self.punch and self.cooldown == 0:
					if self.right:
						self.image = self.StAP
					elif self.left:
						self.image = self.StALP
					self.rect.bottom = 548
					self.speed = self.speed_init
					self.attack_count += 1
					if self.attack_count==20:
						self.punch = False
						self.attack_count = 0
						self.tracker += 1
						self.cooldown = 25
				elif self.kick and self.cooldown == 0:
					if self.right:
						self.image = self.StAK
					elif self.left:
						self.image = self.StALK
					self.rect.bottom = 548
					self.speed = self.speed_init
					self.attack_count += 1
					if self.attack_count==20:
						self.kick = False
						self.attack_count = 0
						self.tracker += 1
						self.cooldown = 50
					
				else:
					self.rect.bottom = 548
					self.speed = self.speed_init				
					if self.right:
						self.image = self.StA				
					elif self.left:
						self.image = self.StAL


			elif self.ducking and not self.special:
				self.speed = self.speed_init/4
				self.rect.top = 432			
				if self.punch:
					if self.right:
						self.image = self.DuAP
					elif self.left:
						self.image = self.DuALP
					self.attack_count += 1
					if self.attack_count==20:
						self.punch = False
						self.attack_count = 0
						self.tracker += 1
				else:
					if self.left:
						self.image = self.DuAL			
					elif self.right:
						self.image = self.DuA
					
			elif self.jumping and not self.special:
				if self.kick:
					if self.right:
						self.image = self.JuAK
					elif self.left:
						self.image = self.JuALK
					self.rect.bottom = 489
					self.speed = self.speed_init
					self.attack_count += 1
					if self.attack_count==20:
						self.kick = False
						self.attack_count = 0
						self.tracker += 1				
				else:
					if self.left:
						self.image = self.JuAL
					elif self.right:
						self.image = self.JuA
					self.rect.bottom = 484
			elif self.special:
				if self.left:
					self.image = self.SpAL
				if self.right:
					self.image = self.SpA				
				self.speed = self.speed_init
				self.rect.centery = 460
				self.specialcount += 1
				if self.specialcount == 2:
					self.condition = False
				
				if self.specialcount == 300 and self.adithyaspecial:
					self.special = False
					self.specialcount = 0
					self.condition = True
				if self.specialcount == 315 and self.krishnaspecial:
					self.special = False
					self.specialcount = 0
					self.condition = True					
				if self.specialcount == 300 and self.sorenspecial:
					self.special = False
					self.specialcount = 0
					self.condition = True		
				if self.specialcount== 100 and self.gabespecial:
					self.special = False
					self.specialcount = 0
					self.condition = True						
	def reset(self):
		if self.player == 2:
			self.left = False
			self.right = True
		if self.player == 1:
			self.right = False
			self.left = True
		self.ducking = False
		self.jumping = False
		self.punch = False
		self.kick = False
		self.special = False
		self.moving_right = False
		self.moving_left = False
		self.hp = self.hp_init	
		self.condition = True	
		if self.player == 2:
			self.init_image = self.StA
		else:
			self.init_image = self.StAL
		self.rect = self.init_image.get_rect()
		self.attack_count = 0
		self.tracker = 0
		if self.player == 2:
			self.rect.centerx = 50
		if self.player == 1:
			self.rect.centerx = 1046
		self.rect.bottom = 548
		self.image = self.init_image
		self.center = float(self.rect.centerx)
		self.vcenter = float(self.rect.centery)
		self.specialcount = 0
