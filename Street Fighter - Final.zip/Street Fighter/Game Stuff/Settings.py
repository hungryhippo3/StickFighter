import random
import pygame
class GameSettings():
	
	def __init__(self, screen):
		#Screen settings
		self.screen_width = 1098
		self.screen_height = 618
		self.screen = screen
		self.menutheme = 'MenuTheme.mp3'
		self.backgrounds = ['Dojo.png', 'Temple.png', 'Beach.png', 'Jungle.png']
		self.choice = random.choice(self.backgrounds)
		self.background = pygame.image.load(self.choice).convert()
		if self.choice == 'Temple.png': 
			self.music = 'TempleTheme.mp3'
			self.floorcolor = (205, 188, 145)
		elif self.choice == 'Dojo.png': 
			self.music = 'DojoTheme.mp3'
			self.floorcolor = (255, 224, 224)
		elif self.choice == 'Beach.png': 
			self.music = 'BeachTheme.mp3'
			self.floorcolor = (217, 216, 93)
		elif self.choice == 'Jungle.png': 
			self.music = 'JungleTheme.mp3'
			self.floorcolor = (139, 105, 20)
		self.blast = pygame.mixer.Sound('Blast.wav')
		self.swing = pygame.mixer.Sound('Swing.wav')
		self.bleep = pygame.mixer.Sound('Bleep.wav')
		self.pop = pygame.mixer.Sound('Pop.wav')
		self.splat = pygame.mixer.Sound('Splat.wav')
		self.popa = 0
		self.splata = 0
		self.splattrue = False
		self.poptrue = False
		self.bleeptrue = False
		self.swingtrue = False
		self.blasttrue = False
		self.game_active = False
		self.choose_active = False
		self.spikeball = None
		self.spikeball2 = None
		self.spikeball3 = None
		self.ketchup = None
		self.ketchup2 = None
		self.communism = None
		self.glitch = None
		self.ng = False
		self.game = False
	def regen(self):
		self.backgrounds = ['Dojo.png', 'Temple.png', 'Beach.png', 'Jungle.png']
		self.choice = random.choice(self.backgrounds)
		self.background = pygame.image.load(self.choice).convert()
		if self.choice == 'Temple.png': 
			self.music = 'TempleTheme.mp3'
			self.floorcolor = (205, 188, 145)
		elif self.choice == 'Dojo.png': 
			self.music = 'DojoTheme.mp3'
			self.floorcolor = (255, 224, 224)
		elif self.choice == 'Beach.png': 
			self.music = 'BeachTheme.mp3'
			self.floorcolor = (217, 216, 93)
		elif self.choice == 'Jungle.png': 
			self.music = 'JungleTheme.mp3'
			self.floorcolor = (139, 105, 20)
		
